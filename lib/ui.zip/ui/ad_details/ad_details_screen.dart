import 'package:mazady/custom_widgets/buttons/custom_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:mazady/custom_widgets/safe_area/page_container.dart';
import 'package:mazady/locale/app_localizations.dart';
import 'package:mazady/models/ad.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:mazady/models/ad_details.dart';
import 'package:mazady/networking/api_provider.dart';
import 'package:mazady/providers/ad_details_provider.dart';
import 'package:mazady/providers/auth_provider.dart';
import 'package:mazady/providers/favourite_provider.dart';
import 'package:mazady/ui/chat/chat_screen.dart';
import 'package:mazady/ui/seller/seller_screen.dart';
import 'package:mazady/ui/section_ads/section_ads_screen.dart';
import 'package:mazady/utils/app_colors.dart';
import 'package:mazady/utils/commons.dart';
import 'package:mazady/utils/urls.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:mazady/utils/error.dart';
import 'package:share/share.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import 'dart:math' as math;
import 'package:mazady/ui/ad_details/widgets/slider_images.dart';
import 'package:mazady/providers/home_provider.dart';
import 'package:mazady/ui/comments/comment_bottom_sheet.dart';
import 'package:mazady/ui/comment/comment_screen.dart';
import 'package:mazady/ui/auth/login_screen.dart';
import 'package:mazady/custom_widgets/no_data/no_data.dart';
import 'package:mazady/custom_widgets/custom_text_form_field/custom_text_form_field.dart';
import 'package:mazady/custom_widgets/MainDrawer.dart';
import 'package:gesture_zoom_box/gesture_zoom_box.dart';

class AdDetailsScreen extends StatefulWidget {
  final Ad ad;

  const AdDetailsScreen({Key key, this.ad}) : super(key: key);
  @override
  _AdDetailsScreenState createState() => _AdDetailsScreenState();
}

class _AdDetailsScreenState extends State<AdDetailsScreen> {
  double _height = 0, _width = 0;
  ApiProvider _apiProvider = ApiProvider();
  AuthProvider _authProvider;
  BitmapDescriptor pinLocationIcon;
  Set<Marker> _markers = {};
  Completer<GoogleMapController> _controller = Completer();
  HomeProvider _homeProvider;
  String reportValue;

  @override
  void initState() {
    super.initState();
    setCustomMapPin();
  }

  void setCustomMapPin() async {
    pinLocationIcon = await BitmapDescriptor.fromAssetImage(
      ImageConfiguration(devicePixelRatio: 2.5),
      'assets/images/pin.png',
    );
  }

  Widget _buildRow(
      {@required String imgPath,
      @required String title,
      @required String value}) {
    return Container(
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.grey[300], width: 1)),
      ),
      padding: EdgeInsets.only(top: 12, bottom: 12),
      child: Row(
        children: <Widget>[
          /* Image.asset(
          imgPath,
          color: Color(0xffC5C5C5),
          height: 15,
          width: 15,
        ), */
          Container(
              margin: EdgeInsets.symmetric(horizontal: 5),
              child: Text(
                title,
                style: TextStyle(color: omarColor, fontSize: 14),
              )),
          Spacer(),
          Text(
            value,
            style: TextStyle(color: Colors.black, fontSize: 14),
          ),
        ],
      ),
    );
  }






  Widget _buildRow1(
      {@required String imgPath,
        @required String title,
        @required String value}) {
    return Container(

      padding: EdgeInsets.only(top: 12, bottom: 12),
      child: Row(
        children: <Widget>[
          /* Image.asset(
          imgPath,
          color: Color(0xffC5C5C5),
          height: 15,
          width: 15,
        ), */
          Container(
              margin: EdgeInsets.symmetric(horizontal: 5),
              child: Text(
                title+" : ",
                style: TextStyle(color: omarColor, fontSize: 15),
              )),

          Text(
            value,
            style: TextStyle(color: Colors.black, fontSize: 15),
          ),
        ],
      ),
    );
  }

  void _settingModalBottomSheet(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return Container(
            child: new Wrap(
              children: <Widget>[
                Padding(padding: EdgeInsets.all(15)),
                Container(
                  child: Text(_homeProvider.currentLang == "ar"
                      ? "ارسال بلاغ :-"
                      : "Send report :-"),
                ),
                Padding(padding: EdgeInsets.all(15)),
                Container(
                  child: CustomTextFormField(
                    hintTxt: _homeProvider.currentLang == "ar"
                        ? "سبب البلاغ"
                        : "Report reason",
                    onChangedFunc: (text) async {
                      reportValue = text;
                    },
                  ),
                ),
                CustomButton(
                  btnColor: mainAppColor,
                  btnLbl: _homeProvider.currentLang == "ar" ? "ارسال" : "Send",
                  onPressedFunction: () async {
                    if (reportValue != null) {
                      final results = await _apiProvider.post(
                          Urls.REPORT_AD_URL +
                              "?api_lang=${_authProvider.currentLang}",
                          body: {
                            "report_user": _authProvider.currentUser.userId,
                            "report_gid": widget.ad.adsId,
                            "report_value": reportValue,
                          });

                      if (results['response'] == "1") {
                        Commons.showToast(context, message: results["message"]);
                        Navigator.pop(context);
                      } else {
                        Commons.showError(context, results["message"]);
                      }
                    } else {
                      Commons.showError(context, "يجب ادخال سبب البلاغ");
                    }
                  },
                ),
                Padding(padding: EdgeInsets.all(10)),
              ],
            ),
          );
        });
  }

  Widget _buildBodyItem() {
    return FutureBuilder<AdDetails>(
        future: Provider.of<AdDetailsProvider>(context, listen: false)
            .getAdDetails(widget.ad.adsId),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.none:
              return Center(
                child: SpinKitFadingCircle(color: mainAppColor),
              );
            case ConnectionState.active:
              return Text('');
            case ConnectionState.waiting:
              return Center(
                child: SpinKitFadingCircle(color: mainAppColor),
              );
            case ConnectionState.done:
              if (snapshot.hasError) {
                return Error(
                  //  errorMessage: snapshot.error.toString(),
                  errorMessage: AppLocalizations.of(context).translate('error'),
                );
              } else {
                List comments = snapshot.data.adsComments;
                // List related= snapshot.data.adsRelated;
                //var initalLocation = snapshot.data.adsLocation.
                //split(',');
                // LatLng pinPosition = LatLng(double.parse(initalLocation[0]), double.parse(initalLocation[1]));

                // these are the minimum required values to set
                // the camera position
                // CameraPosition initialLocation = CameraPosition(
                //  zoom: 15,
                //  bearing: 30,
                //  target: pinPosition
                //  );

                return ListView(
                  children: <Widget>[
                    (_homeProvider.omarKey == "1")
                        ? GestureDetector(
                            child: CustomButton(
                              btnLbl: _homeProvider.currentLang == "ar"
                                  ? "اخفاء المحتوى من هذا المعلن"
                                  : "Hide content from this advertiser",
                              btnColor: mainAppColor,
                              onPressedFunction: () async {
                                final results = await _apiProvider.post(
                                    "https://mazadiy.com/api/report999" +
                                        "?api_lang=${_authProvider.currentLang}",
                                    body: {
                                      // "report_user": _authProvider.currentUser.userId,
                                      "report_gid": widget.ad.adsId,
                                      //"report_value": reportValue,
                                    });

                                if (results['response'] == "1") {
                                  Commons.showToast(context,
                                      message: results["message"]);
                                  Navigator.pop(context);
                                } else {
                                  Commons.showError(
                                      context, results["message"]);
                                }
                              },
                            ),
                          )
                        : Text(
                            " ",
                            style: TextStyle(height: 0),
                          ),
                    snapshot.data.photos.length == 1
                        ? Container(
                            height: 255,
                            margin: EdgeInsets.symmetric(horizontal: 0),
                            child: GestureDetector(
                              onTap: () {
                                showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return Dialog(
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                20.0)), //this right here
                                        child: Container(
                                          child: GestureZoomBox(
                                            maxScale: 5.0,
                                            doubleTapScale: 2.0,
                                            duration:
                                                Duration(milliseconds: 200),
                                            onPressed: () =>
                                                Navigator.pop(context),
                                            child: Image.network(
                                              snapshot.data.adsMainPhoto,
                                              fit: BoxFit.fill,
                                              width: MediaQuery.of(context)
                                                  .size
                                                  .width,
                                            ),
                                          ),
                                        ),
                                      );
                                    });
                              },
                              child: ClipRRect(
                                child: Image.network(
                                  snapshot.data.adsMainPhoto,
                                  fit: BoxFit.fill,
                                  width: MediaQuery.of(context).size.width,
                                ),
                              ),
                            ),
                          )
                        : Container(
                            height: 200,
                            margin: EdgeInsets.symmetric(
                                horizontal: _width * 0.04,
                                vertical: _height * 0.01),
                            child: SliderImages(),
                          ),
                    Container(
                      margin: EdgeInsets.symmetric(
                          horizontal: _width * 0.04, vertical: _height * 0.01),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                widget.ad.adsTitle,
                                style: TextStyle(
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                              Padding(padding: EdgeInsets.all(3)),
                              Text(
                                widget.ad.adsCityName,
                                style: TextStyle(
                                    fontSize: 14, color: Colors.black),
                              ),
                            ],
                          ),
                          Spacer(),
                          Container(
                              margin: EdgeInsets.only(
                                right:
                                    _authProvider.currentLang != 'ar' ? 5 : 0,
                                left: _authProvider.currentLang == 'ar' ? 5 : 0,
                              ),
                              height: _height * 0.04,
                              width: _width * 0.07,
                              decoration: BoxDecoration(
                                  color: mainAppColor,
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(30.0),
                                  ),
                                  border: Border.all(
                                    width: 1.5,
                                    color: mainAppColor,
                                  )),
                              child: _authProvider.currentUser == null
                                  ? GestureDetector(
                                      onTap: () => Navigator.pushNamed(
                                          context, '/login_screen'),
                                      child: Center(
                                          child: Icon(
                                        Icons.favorite_border,
                                        size: 22,
                                        color: Colors.white,
                                      )),
                                    )
                                  : Consumer<FavouriteProvider>(builder:
                                      (context, favouriteProvider, child) {
                                      return GestureDetector(
                                        onTap: () async {
                                          if (favouriteProvider.favouriteAdsList
                                              .containsKey(
                                                  snapshot.data.adsId)) {
                                            favouriteProvider
                                                .removeFromFavouriteAdsList(
                                                    snapshot.data.adsId);
                                            await _apiProvider.get(Urls
                                                    .REMOVE_AD_from_FAV_URL +
                                                "ads_id=${snapshot.data.adsId}&user_id=${_authProvider.currentUser.userId}");
                                          } else {
                                            favouriteProvider
                                                .addToFavouriteAdsList(
                                                    snapshot.data.adsId, 1);
                                            await _apiProvider.post(
                                                Urls.ADD_AD_TO_FAV_URL,
                                                body: {
                                                  "user_id": _authProvider
                                                      .currentUser.userId,
                                                  "ads_id": snapshot.data.adsId
                                                });
                                          }
                                        },
                                        child: Center(
                                          child: favouriteProvider
                                                  .favouriteAdsList
                                                  .containsKey(
                                                      snapshot.data.adsId)
                                              ? SpinKitPumpingHeart(
                                                  color: accentColor,
                                                  size: 22,
                                                )
                                              : Icon(
                                                  Icons.favorite_border,
                                                  size: 22,
                                                  color: Colors.white,
                                                ),
                                        ),
                                      );
                                    })),

                          Container(
                              margin: EdgeInsets.only(
                                right:
                                _authProvider.currentLang != 'ar' ? 5 : 0,
                                left: _authProvider.currentLang == 'ar' ? 5 : 0,
                              ),
                              height: _height * 0.04,
                              width: _width * 0.07,
                              decoration: BoxDecoration(
                                  color: Color(0xff303030),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(30.0),
                                  ),
                                  border: Border.all(
                                    width: 1.5,
                                    color:  Color(0xff303030),
                                  )),
                              child: GestureDetector(
                                onTap: () {
                                  Share.share(widget.ad.adsTitle+" -  الصورة : "+ widget.ad.adsPhoto+" - مشاركة من تطبيق مزادي   - ",
                                  );
                                },
                                child: Icon(FontAwesomeIcons.shareAlt,color: Colors.white,size: 22,),
                              )),
                          

                          Container(
                              margin: EdgeInsets.only(
                                right:
                                    _authProvider.currentLang != 'ar' ? 5 : 0,
                                left: _authProvider.currentLang == 'ar' ? 5 : 0,
                              ),
                              height: _height * 0.04,
                              width: _width * 0.07,
                              decoration: BoxDecoration(
                                  color: Color(0xff303030),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(30.0),
                                  ),
                                  border: Border.all(
                                    width: 1.5,
                                    color:  Color(0xff303030),
                                  )),
                              child: GestureDetector(
                                onTap: () {
                                  launch(
                                      "https://wa.me/${snapshot.data.adsWhatsapp}");
                                },
                                child: Icon(FontAwesomeIcons.whatsapp,color: Colors.white,size: 22,),
                              ))
                        ],
                      ),
                    ),

          Container(
            alignment: Alignment.center,
          
          padding: EdgeInsets.all(5),
          margin: EdgeInsets.only(left:  _width * 0.04,right:  _width * 0.70),
          decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10.0)),
          border: Border.all(
          color: hintColor.withOpacity(0.4),
          ),
          color: Colors.white,
          boxShadow: [
          BoxShadow(
          color: Colors.grey.withOpacity(0.4),
          blurRadius: 6,
          ),
          ],
          ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text("السعر",style: TextStyle(color: omarColor,fontSize: 12),),
               Row(
                 mainAxisAlignment: MainAxisAlignment.center,
                 crossAxisAlignment: CrossAxisAlignment.center,
                 children: <Widget>[

                   Text("SR",style: TextStyle(color: mainAppColor,fontSize: 18,fontWeight: FontWeight.bold),),
                   Padding(padding: EdgeInsets.all(5)),
                   Text(snapshot.data.adsPrice,style: TextStyle(color: Colors.black,fontSize: 18),),
                 ],
               )

              ],
            ),
          ),
                    SizedBox(height: 15,),
                    Container(
                      height: 190,
                      margin: EdgeInsets.symmetric(horizontal: _width * 0.04),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        border: Border.all(
                          color: hintColor.withOpacity(0.4),
                        ),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.4),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 5,
                          ),
                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow(
                                  imgPath: 'assets/images/edit.png',
                                  title: AppLocalizations.of(context)
                                      .translate('ad_no'),
                                  value: snapshot.data.adsId)),
                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04,
                                  vertical: _height * 0.001),
                              child: _buildRow(
                                  imgPath: 'assets/images/time.png',
                                  title: AppLocalizations.of(context)
                                      .translate('ad_time'),
                                  value: snapshot.data.adsDate)),
                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04,
                                  vertical: _height * 0.001),
                              child: _buildRow(
                                  imgPath: 'assets/images/city.png',
                                  title: AppLocalizations.of(context)
                                      .translate('city'),
                                  value: snapshot.data.adsCityName)),
                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04,
                                  vertical: _height * 0.001),
                              child: _buildRow(
                                  imgPath: 'assets/images/view.png',
                                  title: AppLocalizations.of(context)
                                      .translate('watches_no'),
                                  value: snapshot.data.adsVisits)),
                        ],
                      ),
                    ),
                    snapshot.data.adsCat == "1"
                        ? SizedBox(
                            height: 10,
                          )
                        : Text(
                            ' ',
                            style: TextStyle(height: 0),
                          ),














                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "9")
                        ? Container(


                            margin:
                                EdgeInsets.symmetric(horizontal: _width * 0.04),

                            child: Column(
                              children: <Widget>[
                                SizedBox(
                                  height: 10,
                                ),

                                Container(
                                color: accentColor,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "عدد النجوم"
                                            : "Number of stars",
                                        value: snapshot.data.adsStars != null
                                            ? snapshot.data.adsStars
                                            : _homeProvider.currentLang == "ar"
                                                ? "غير محدد"
                                                : "undefined")),


                                Container(
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "عدد الوحدات"
                                            : "number of units",
                                        value: snapshot.data.adsItemsNumber != null
                                            ? snapshot.data.adsItemsNumber
                                            : _homeProvider.currentLang == "ar"
                                            ? "غير محدد"
                                            : "undefined")),




                                Container(
                                    color: accentColor,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "عدد الادوار"
                                            : "Number of roles",
                                        value: snapshot.data.adsDoorsNumber != null
                                            ? snapshot.data.adsDoorsNumber
                                            : _homeProvider.currentLang == "ar"
                                            ? "غير محدد"
                                            : "undefined")),




                                Container(
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "المساحة"
                                            : "Space",
                                        value: snapshot.data.adsArea != null
                                            ? snapshot.data.adsArea
                                            : _homeProvider.currentLang == "ar"
                                            ? "غير محدد"
                                            : "undefined")),


                                Container(
                                    color: accentColor,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "الحي"
                                            : "Neighborhood",
                                        value: snapshot.data.adsAdress != null
                                            ? snapshot.data.adsAdress
                                            : _homeProvider.currentLang == "ar"
                                            ? "غير محدد"
                                            : "undefined")),



                                Container(
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "الشارع"
                                            : "Street",
                                        value: snapshot.data.adsStreet != null
                                            ? snapshot.data.adsStreet
                                            : _homeProvider.currentLang == "ar"
                                            ? "غير محدد"
                                            : "undefined")),



                                Container(
                                    color: accentColor,
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "قاعة / قاعات"
                                            : "Hall (s)",
                                        value: snapshot.data.adsQa3at != null
                                            ? snapshot.data.adsQa3at
                                            : _homeProvider.currentLang == "ar"
                                            ? "غير محدد"
                                            : "undefined")),



                                Container(
                                    margin: EdgeInsets.symmetric(
                                        horizontal: _width * 0.04),
                                    child: _buildRow1(
                                        imgPath: 'assets/images/edit.png',
                                        title: _homeProvider.currentLang == "ar"
                                            ? "مواقف سيارات"
                                            : "Car parking",
                                        value: snapshot.data.adsMwaqef != null
                                            ? snapshot.data.adsMwaqef
                                            : _homeProvider.currentLang == "ar"
                                            ? "غير محدد"
                                            : "undefined")),




                              ],
                            ),
                          )
                        : Text(
                            ' ',
                            style: TextStyle(height: 0),
                          ),









                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "10")
                        ? Container(



                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الواجهة"
                                      : "Interface",
                                  value: snapshot.data.adsFace != null
                                      ? snapshot.data.adsFace
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الوحدات"
                                      : "number of units",
                                  value: snapshot.data.adsItemsNumber != null
                                      ? snapshot.data.adsItemsNumber
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),




                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مصعد"
                                      : "elevator",
                                  value: snapshot.data.adsAsanser != null
                                      ? snapshot.data.adsAsanser
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مشب"
                                      : "JSB",
                                  value: snapshot.data.adsMshb != null
                                      ? snapshot.data.adsMshb
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مواقف سيارات"
                                      : "Car parking",
                                  value: snapshot.data.adsMwaqef != null
                                      ? snapshot.data.adsMwaqef
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),




                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),









                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "11")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الواجهة"
                                      : "Interface",
                                  value: snapshot.data.adsFace != null
                                      ? snapshot.data.adsFace
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الوحدات"
                                      : "number of units",
                                  value: snapshot.data.adsItemsNumber != null
                                      ? snapshot.data.adsItemsNumber
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد المحلات"
                                      : "number of stores",
                                  value: snapshot.data.adsShopsNumber != null
                                      ? snapshot.data.adsShopsNumber
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مصعد"
                                      : "elevator",
                                  value: snapshot.data.adsAsanser != null
                                      ? snapshot.data.adsAsanser
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مشب"
                                      : "JSB",
                                  value: snapshot.data.adsMshb != null
                                      ? snapshot.data.adsMshb
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مواقف سيارات"
                                      : "Car parking",
                                  value: snapshot.data.adsMwaqef != null
                                      ? snapshot.data.adsMwaqef
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),




                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),








                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "12")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الواجهة"
                                      : "Interface",
                                  value: snapshot.data.adsFace != null
                                      ? snapshot.data.adsFace
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الغرف"
                                      : "number of rooms",
                                  value: snapshot.data.adsRoomNumbers != null
                                      ? snapshot.data.adsRoomNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد دورات المياه"
                                      : "number of toilets",
                                  value: snapshot.data.adsBathNumbers != null
                                      ? snapshot.data.adsBathNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الصالات"
                                      : "number of halled",
                                  value: snapshot.data.adsHallNumbers != null
                                      ? snapshot.data.adsHallNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد المطابخ"
                                      : "number of kitchens",
                                  value: snapshot.data.adsKithchenNumber != null
                                      ? snapshot.data.adsKithchenNumber
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مصعد"
                                      : "elevator",
                                  value: snapshot.data.adsAsanser != null
                                      ? snapshot.data.adsAsanser
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مدخل السيارة"
                                      : "Entrance to the car",
                                  value: snapshot.data.adsCarPath != null
                                      ? snapshot.data.adsCarPath
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),





                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "حوش"
                                      : "Hoosh",
                                  value: snapshot.data.adsHoosh != null
                                      ? snapshot.data.adsHoosh
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مشب"
                                      : "JSB",
                                  value: snapshot.data.adsMshb != null
                                      ? snapshot.data.adsMshb
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),
























                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "13")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),




                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الغرف"
                                      : "number of rooms",
                                  value: snapshot.data.adsRoomNumbers != null
                                      ? snapshot.data.adsRoomNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد دورات المياه"
                                      : "number of toilets",
                                  value: snapshot.data.adsBathNumbers != null
                                      ? snapshot.data.adsBathNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الصالات"
                                      : "number of halled",
                                  value: snapshot.data.adsHallNumbers != null
                                      ? snapshot.data.adsHallNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد المطابخ"
                                      : "number of kitchens",
                                  value: snapshot.data.adsKithchenNumber != null
                                      ? snapshot.data.adsKithchenNumber
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مصعد"
                                      : "elevator",
                                  value: snapshot.data.adsAsanser != null
                                      ? snapshot.data.adsAsanser
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مدخل السيارة"
                                      : "Entrance to the car",
                                  value: snapshot.data.adsCarPath != null
                                      ? snapshot.data.adsCarPath
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),





                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "حوش"
                                      : "Hoosh",
                                  value: snapshot.data.adsHoosh != null
                                      ? snapshot.data.adsHoosh
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مشب"
                                      : "JSB",
                                  value: snapshot.data.adsMshb != null
                                      ? snapshot.data.adsMshb
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),











                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "14")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),




                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الموقع"
                                      : "location",
                                  value: snapshot.data.adsLocation != null
                                      ? snapshot.data.adsLocation
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "بئر ماء"
                                      : "Water well",
                                  value: snapshot.data.adsBeer != null
                                      ? snapshot.data.adsBeer
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "رشاشات ري"
                                      : "Irrigation sprinklers",
                                  value: snapshot.data.adsRshashat != null
                                      ? snapshot.data.adsRshashat
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),





                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),
















                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "15")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الواجهة"
                                      : "Interface",
                                  value: snapshot.data.adsFace != null
                                      ? snapshot.data.adsFace
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),













                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "16")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),




                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الغرف"
                                      : "number of rooms",
                                  value: snapshot.data.adsRoomNumbers != null
                                      ? snapshot.data.adsRoomNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد دورات المياه"
                                      : "number of toilets",
                                  value: snapshot.data.adsBathNumbers != null
                                      ? snapshot.data.adsBathNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد الصالات"
                                      : "number of halled",
                                  value: snapshot.data.adsHallNumbers != null
                                      ? snapshot.data.adsHallNumbers
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "عدد المطابخ"
                                      : "number of kitchens",
                                  value: snapshot.data.adsKithchenNumber != null
                                      ? snapshot.data.adsKithchenNumber
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مسبح"
                                      : "Swimming pool",
                                  value: snapshot.data.adsMsbh != null
                                      ? snapshot.data.adsMsbh
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مدخل السيارة"
                                      : "Entrance to the car",
                                  value: snapshot.data.adsCarPath != null
                                      ? snapshot.data.adsCarPath
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),





                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "ملعب"
                                      : "Playground",
                                  value: snapshot.data.adsMl2b != null
                                      ? snapshot.data.adsMl2b
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مشب"
                                      : "JSB",
                                  value: snapshot.data.adsMshb != null
                                      ? snapshot.data.adsMshb
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),







                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "17")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),







                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الموقع"
                                      : "location",
                                  value: snapshot.data.adsLocation!= null
                                      ? snapshot.data.adsLocation
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "السعر"
                                      : "price",
                                  value: snapshot.data.adsPrice != null
                                      ? snapshot.data.adsPrice
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),






                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "مواقف سيارات"
                                      : "Car parking",
                                  value: snapshot.data.adsMwaqef != null
                                      ? snapshot.data.adsMwaqef
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),




                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),












                    (snapshot.data.adsCat == "1" && snapshot.data.adsSub == "18")
                        ? Container(


                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "المساحة"
                                      : "Space",
                                  value: snapshot.data.adsArea != null
                                      ? snapshot.data.adsArea
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الموقع"
                                      : "location",
                                  value: snapshot.data.adsLocation!= null
                                      ? snapshot.data.adsLocation
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "السعر"
                                      : "price",
                                  value: snapshot.data.adsPrice != null
                                      ? snapshot.data.adsPrice
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الحي"
                                      : "Neighborhood",
                                  value: snapshot.data.adsAdress != null
                                      ? snapshot.data.adsAdress
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الشارع"
                                      : "Street",
                                  value: snapshot.data.adsStreet != null
                                      ? snapshot.data.adsStreet
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),














                    (snapshot.data.adsCat == "2")
                        ? Container(

                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الموديل"
                                      : "Model",
                                  value: snapshot.data.adsModel != null
                                      ? snapshot.data.adsModel
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "البيانات الاساسية"
                                      : "basic information",
                                  value: snapshot.data.adsAsasia!= null
                                      ? snapshot.data.adsAsasia
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "نوع البيع"
                                      : "Type of sale",
                                  value: snapshot.data.adsSellType != null
                                      ? snapshot.data.adsSellType
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "حالة المركبة"
                                      : "Vehicle condition",
                                  value: snapshot.data.adsCarState != null
                                      ? snapshot.data.adsCarState
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "نوع ناقل الحركة"
                                      : "Transmission type",
                                  value: snapshot.data.adsQeerType != null
                                      ? snapshot.data.adsQeerType
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),





                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "نوع الوقود"
                                      : "Fuel type",
                                  value: snapshot.data.adsWqoodType != null
                                      ? snapshot.data.adsWqoodType
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),


                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "يوجد دبل"
                                      : "There is a double",
                                  value: snapshot.data.adsDblFound != null
                                      ? snapshot.data.adsDblFound
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الممشي"
                                      : "Walkway",
                                  value: snapshot.data.adsMmsha != null
                                      ? snapshot.data.adsMmsha
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),














                    (snapshot.data.adsCat == "3")
                        ? Container(

                      margin:
                      EdgeInsets.symmetric(horizontal: _width * 0.04),


                      child: Column(
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),



                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الماركة"
                                      : "Marka",
                                  value: snapshot.data.adsMarka != null
                                      ? snapshot.data.adsMarka
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الموديل"
                                      : "Model",
                                  value: snapshot.data.adsModel != null
                                      ? snapshot.data.adsModel
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "البيانات الاساسية"
                                      : "basic information",
                                  value: snapshot.data.adsAsasia!= null
                                      ? snapshot.data.adsAsasia
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),







                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "حالة المعدة"
                                      : "Vehicle condition",
                                  value: snapshot.data.adsCarState != null
                                      ? snapshot.data.adsCarState
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),






                          Container(
                              color: accentColor,
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "يوجد دبل"
                                      : "There is a double",
                                  value: snapshot.data.adsDblFound != null
                                      ? snapshot.data.adsDblFound
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),

                          Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: _width * 0.04),
                              child: _buildRow1(
                                  imgPath: 'assets/images/edit.png',
                                  title: _homeProvider.currentLang == "ar"
                                      ? "الممشي"
                                      : "Walkway",
                                  value: snapshot.data.adsMmsha != null
                                      ? snapshot.data.adsMmsha
                                      : _homeProvider.currentLang == "ar"
                                      ? "غير محدد"
                                      : "undefined")),



                        ],
                      ),
                    )
                        : Text(
                      ' ',
                      style: TextStyle(height: 0),
                    ),




                     SizedBox(height: 20,),

                    Container(
                      margin: EdgeInsets.symmetric(
                        horizontal: _width * 0.04,
                      ),
                      child: Text(
                        AppLocalizations.of(context)
                            .translate('ad_description'),
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.symmetric(
                          horizontal: _width * 0.04,
                        ),
                        child: Text(
                          snapshot.data.adsDetails,
                          style: TextStyle(height: 1.4, fontSize: 14),
                          textAlign: TextAlign.justify,
                        )),




                SizedBox(
                height: 20,
                ),



                    Container(
                      height: _height * 0.1,
                      margin: EdgeInsets.symmetric(
                          horizontal: _width * 0.04, vertical: _height * 0.01),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        border: Border.all(
                          color: hintColor.withOpacity(0.4),
                        ),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.4),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: _width * 0.025),
                            child: CircleAvatar(
                              backgroundColor: Colors.grey,
                              radius: _height * 0.035,
                              backgroundImage:
                                  NetworkImage(snapshot.data.adsUserPhoto),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              _homeProvider
                                  .setCurrentSeller(snapshot.data.adsUser);
                              _homeProvider.setCurrentSellerName(
                                  snapshot.data.adsUserName);
                              _homeProvider.setCurrentSellerPhone(
                                  snapshot.data.adsUserPhone);
                              _homeProvider.setCurrentSellerPhoto(
                                  snapshot.data.adsUserPhoto);

                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => SellerScreen(
                                            userId: snapshot.data.adsUser,
                                          )));
                            },
                            child: Text(
                              snapshot.data.adsUserName,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                          Spacer(),
                          GestureDetector(
                            onTap: () {
                              launch("tel://${snapshot.data.adsPhone}");
                            },
                            child: Text(snapshot.data.adsUserPhone),
                          ),
                          GestureDetector(
                            onTap: () {
                              launch("tel://${snapshot.data.adsUserPhone}");
                            },
                            child: Container(
                                margin: EdgeInsets.symmetric(
                                    horizontal: _width * 0.025),
                                child:
                                    Image.asset('assets/images/phone1.png')),
                          ),
             
                        ],
                      ),
                    ),


                    Container(
                        margin: EdgeInsets.only(
                            top: 5, bottom: 35, right: 15, left: 15),
                        height: 50,


                        child: GestureDetector(
                            onTap: () {
                              if (_authProvider.currentUser == null) {
                                Commons.showToast(context,
                                    message: "يجب عليك تسجيل الدخول اولا");

                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => LoginScreen()));
                              } else {
                                _homeProvider.setCurrentAds(widget.ad.adsId);

                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => CommentScreen()));
                              }
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Image.asset('assets/images/chat.png'),
                                Container(
                                  margin: EdgeInsets.symmetric(horizontal: 10),
                                  child: Text(
                                    _homeProvider.currentLang=="ar"?"عرض التعليقات":"Show comments",
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700,
                                        color: omarColor),
                                  ),
                                ),
                              ],
                            ))),


                      GestureDetector(
                        child: Container(
                          alignment: Alignment.center,
                          margin: EdgeInsets.only(
                              top: 10, bottom: 10, right: 15, left: 15),
                          height: 50,
                          color: accentColor,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Image.asset(
                                'assets/images/about.png',
                                color: mainAppColor,
                              ),
                              Padding(padding: EdgeInsets.all(3)),
                              Text(_homeProvider.currentLang=="ar"?"أبلغ عن المحتوي":"Report the content",
                              style: TextStyle(
                                color: mainAppColor,
                                fontSize: 14
                              ),
                              )
                            ],
                          ),
                        ),
                        onTap: () async{
                          _settingModalBottomSheet(context);
                        },
                      ),
                    Container(
                        margin: EdgeInsets.only(top: 10),
                        height: 50,
                        decoration: BoxDecoration(
                          color: mainAppColor,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(15),
                              topRight: Radius.circular(15)),
                        ),
                        child: GestureDetector(
                            onTap: () {
                              if (_authProvider.currentUser != null) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => ChatScreen(
                                              senderId: snapshot
                                                  .data.userDetails[0].id,
                                              senderImg: snapshot.data
                                                  .userDetails[0].userImage,
                                              senderName: snapshot
                                                  .data.userDetails[0].name,
                                              senderPhone: snapshot
                                                  .data.userDetails[0].phone,
                                              adsId: snapshot.data.adsId,
                                            )));
                              } else {
                                Navigator.pushNamed(context, '/login_screen');
                              }
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 10),
                                    child:
                                        Image.asset('assets/images/chat.png')),
                                Text(
                                  AppLocalizations.of(context)
                                      .translate('send_to_advertiser'),
                                  style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white),
                                ),
                              ],
                            ))),
                    SizedBox(
                      height: 5,
                    ),
                  ],
                );
              }
          }
          return Center(
            child: SpinKitFadingCircle(color: mainAppColor),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    final appBar = AppBar(
      automaticallyImplyLeading: false,
      elevation: 0,
      backgroundColor: Colors.white,
      centerTitle: true,


      title: Text(
        widget.ad.adsTitle,
        style: TextStyle(fontSize: 15, color: omarColor),
      ),
      actions: <Widget>[
        IconButton(
            icon: Consumer<AuthProvider>(
              builder: (context, authProvider, child) {
                return authProvider.currentLang == 'ar'
                    ? Image.asset(
                        'assets/images/left.png',
                        color: omarColor,
                      )
                    : Transform.rotate(
                        angle: 180 * math.pi / 180,
                        child: Image.asset(
                          'assets/images/left.png',
                          color: omarColor,
                        ));
              },
            ),
            onPressed: () => Navigator.pop(context))
      ],
    );

    _height =
        MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top;
    _width = MediaQuery.of(context).size.width;
    _authProvider = Provider.of<AuthProvider>(context);
    _homeProvider = Provider.of<HomeProvider>(context);
    return PageContainer(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: appBar,
        body: _buildBodyItem(),
      ),
    );
  }
}
